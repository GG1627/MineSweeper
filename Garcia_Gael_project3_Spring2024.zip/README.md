Name: Gael Garcia
Section: 23372
UFL email: gael.garcia@ufl.edu
System: Windows
Compiler: g++ 64 bit
SFML version: 2.6
IDE: CLion
Other notes: none ^-^ have a great summer!!! goated TA